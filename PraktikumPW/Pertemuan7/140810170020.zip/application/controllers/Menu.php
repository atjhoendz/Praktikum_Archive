<?php
     class Menu extends CI_Controller{
          public function index(){
               $this->load->view('menu_view');
          }
     }
?>
